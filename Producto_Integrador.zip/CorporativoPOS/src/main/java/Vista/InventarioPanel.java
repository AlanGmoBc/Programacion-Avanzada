package Vista;

import javax.swing.*;
import javax.swing.table.*;
import Controlador.InventarioControlador;
import Modelo.*;
import Util.ManejoErrores;
import java.awt.*;
import java.util.List;
import java.io.File;
import Util.RutaBase;

public class InventarioPanel extends JPanel {

	private final InventarioControlador ctrl;
	private final Usuario usuarioActivo;

	private JTextField txtBusqueda;
	private JComboBox<String> cmbCategoria;
	private DefaultTableModel modeloTabla;
	private JTable tabla;

	public InventarioPanel(InventarioControlador ctrl, Usuario usuario) {
		this.ctrl = ctrl;
		this.usuarioActivo = usuario;
		setLayout(null);
		setBackground(Estilos.BG_CLARO);
		construir();
	}

	private void construir() {
		JLabel titulo = new JLabel("CATALOGO — Administracion de Stock");
		titulo.setFont(Estilos.FUENTE_TITULO);
		titulo.setForeground(Estilos.TEXTO_PRINCIPAL);
		titulo.setBounds(24, 16, 600, 30);
		add(titulo);

		if (usuarioActivo.esAdmin()) {
			JButton btnDevolver = Estilos.botonPeligro("Devolver");
			btnDevolver.setBounds(450, 14, 90, 36);
			btnDevolver.addActionListener(e -> {
				int row = tabla.getSelectedRow();
				if (row < 0) {
					JOptionPane.showMessageDialog(this, "Seleccione un producto de la tabla");
					return;
				}
				String id = (String) modeloTabla.getValueAt(row, 0);
				new DevolucionProveedorDialog(SwingUtilities.getWindowAncestor(this), ctrl.buscarPorId(id), ctrl).setVisible(true);
			});
			add(btnDevolver);

			JButton btnEntrada = Estilos.botonSecundario("Entrada");
			btnEntrada.setBounds(550, 14, 90, 36);
			btnEntrada.addActionListener(e -> {
				int row = tabla.getSelectedRow();
				if (row < 0) {
					JOptionPane.showMessageDialog(this, "Seleccione un producto de la tabla");
					return;
				}
				String id = (String) modeloTabla.getValueAt(row, 0);
				new EntradaRapidaDialog(SwingUtilities.getWindowAncestor(this), ctrl.buscarPorId(id), ctrl).setVisible(true);
			});
			add(btnEntrada);
		}

		JButton btnBajoStock = Estilos.botonSecundario("Bajo Stock");
		btnBajoStock.setBounds(650, 14, 130, 36);
		btnBajoStock.addActionListener(e -> mostrarBajoStock());
		add(btnBajoStock);

		if (usuarioActivo.esAdmin()) {
			JButton btnNuevo = Estilos.botonPrimario("+ Nuevo Item");
			btnNuevo.setBounds(790, 14, 130, 36);
			btnNuevo.addActionListener(e -> abrirFormulario(null));
			add(btnNuevo);
		}

		JLabel lblBusq = new JLabel("BUSCAR:");
		lblBusq.setFont(Estilos.FUENTE_XS);
		lblBusq.setForeground(Estilos.TEXTO_TENUE);
		lblBusq.setBounds(24, 62, 60, 14);
		add(lblBusq);

		txtBusqueda = new JTextField();
		txtBusqueda.setFont(Estilos.FUENTE_BOLD);
		txtBusqueda.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Estilos.BORDE, 2),
				BorderFactory.createEmptyBorder(6, 10, 6, 10)));
		txtBusqueda.setBackground(Estilos.BG_BLANCO);
		txtBusqueda.setBounds(80, 56, 280, 34);
		txtBusqueda.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
			public void insertUpdate(javax.swing.event.DocumentEvent e) {
				refrescar();
			}

			public void removeUpdate(javax.swing.event.DocumentEvent e) {
				refrescar();
			}

			public void changedUpdate(javax.swing.event.DocumentEvent e) {
				refrescar();
			}
		});
		add(txtBusqueda);

		JLabel lblCat = new JLabel("CATEGORIA:");
		lblCat.setFont(Estilos.FUENTE_XS);
		lblCat.setForeground(Estilos.TEXTO_TENUE);
		lblCat.setBounds(376, 62, 80, 14);
		add(lblCat);

		String[] cats = DatosIniciales.getCategorias();
		String[] catConTodas = new String[cats.length + 1];
		catConTodas[0] = "Todas";
		System.arraycopy(cats, 0, catConTodas, 1, cats.length);
		cmbCategoria = new JComboBox<>(catConTodas);
		cmbCategoria.setFont(Estilos.FUENTE_BOLD);
		cmbCategoria.setBounds(454, 56, 200, 34);
		cmbCategoria.addActionListener(e -> refrescar());
		add(cmbCategoria);

		String[] cols = { "SKU", "Foto", "Producto", "Categoria", "Precio", "Existencia", "Stock Min", "Estado" };
		modeloTabla = new DefaultTableModel(cols, 0) {
			@Override
			public boolean isCellEditable(int r, int c) {
				return false;
			}
		};

		tabla = new JTable(modeloTabla);
		tabla.setFont(Estilos.FUENTE_NORMAL);
		tabla.setRowHeight(55);

		tabla.getColumnModel().getColumn(1).setPreferredWidth(60);
		tabla.getColumnModel().getColumn(1).setCellRenderer(new ImagenRenderer());

		tabla.setShowGrid(false);
		tabla.setIntercellSpacing(new Dimension(0, 2));
		tabla.getTableHeader().setFont(Estilos.FUENTE_XS);
		tabla.getTableHeader().setBackground(Estilos.BG_ZINC_100);

		tabla.getColumnModel().getColumn(0).setMaxWidth(70);
		tabla.getColumnModel().getColumn(4).setMaxWidth(100);
		tabla.getColumnModel().getColumn(5).setMaxWidth(90);
		tabla.getColumnModel().getColumn(6).setMaxWidth(80);
		tabla.getColumnModel().getColumn(7).setMaxWidth(80);

		tabla.addMouseListener(new java.awt.event.MouseAdapter() {
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
				if (e.getClickCount() == 2 && usuarioActivo.esAdmin()) {
					int row = tabla.getSelectedRow();
					if (row >= 0) {
						String id = (String) modeloTabla.getValueAt(row, 0);
						abrirFormulario(ctrl.buscarPorId(id));
					}
				}
			}
		});

		JScrollPane scroll = new JScrollPane(tabla);
		scroll.setBorder(BorderFactory.createLineBorder(Estilos.BORDE));
		scroll.getViewport().setBackground(Estilos.BG_BLANCO);
		scroll.setBounds(24, 104, 904, 560);
		add(scroll);

		refrescar();
	}

	public void refrescar() {
		String texto = txtBusqueda != null ? txtBusqueda.getText() : "";
		String cat = (cmbCategoria != null && cmbCategoria.getSelectedIndex() > 0)
				? (String) cmbCategoria.getSelectedItem()
				: "";

		List<Producto> lista = ctrl.filtrar(texto, cat);
		modeloTabla.setRowCount(0);

		for (Producto p : lista) {
			modeloTabla.addRow(new Object[] { p.getId(), p.getImagenRuta(), p.getNombre().toUpperCase(),
					p.getCategoria(), String.format("$%.2f", p.getPrecio()), String.format("%.1f", p.getStock()),
					String.format("%.0f", p.getStockMinimo()), p.stockBajo() ? "BAJO" : "OK" });
		}
	}

	private void mostrarBajoStock() {
		List<Producto> todos = ctrl.filtrar("", "");
		List<Producto> bajos = todos.stream().filter(Producto::stockBajo)
				.sorted((a, b) -> Double.compare(a.getStock() - a.getStockMinimo(), b.getStock() - b.getStockMinimo()))
				.collect(java.util.stream.Collectors.toList());

		JDialog dlg = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this),
				"Reporte de Productos con Bajo Stock", true);
		dlg.setSize(720, 480);
		dlg.setLocationRelativeTo(this);
		dlg.setLayout(null);
		dlg.getContentPane().setBackground(Estilos.BG_BLANCO);

		JLabel tit = new JLabel("PRODUCTOS CON STOCK BAJO");
		tit.setFont(Estilos.FUENTE_TITULO);
		tit.setBounds(20, 14, 500, 30);
		dlg.add(tit);

		JLabel sub = new JLabel(bajos.isEmpty()
				? "Todo en orden — ningun producto por debajo del minimo."
				: bajos.size() + " producto(s) requieren reposicion.");
		sub.setFont(Estilos.FUENTE_NORMAL);
		sub.setForeground(bajos.isEmpty() ? Estilos.EMERALD : Estilos.ROSE);
		sub.setBounds(20, 44, 660, 18);
		dlg.add(sub);

		String[] cols = { "SKU", "Nombre", "Categoria", "Stock Actual", "Stock Minimo", "Faltante" };
		DefaultTableModel modelo = new DefaultTableModel(cols, 0) {
			@Override
			public boolean isCellEditable(int r, int c) {
				return false;
			}
		};
		JTable tabla = new JTable(modelo);
		tabla.setFont(Estilos.FUENTE_NORMAL);
		tabla.setRowHeight(36);
		tabla.setShowGrid(false);
		tabla.setIntercellSpacing(new Dimension(0, 2));
		tabla.getTableHeader().setFont(Estilos.FUENTE_XS);
		tabla.getTableHeader().setBackground(Estilos.BG_ZINC_100);
		tabla.getColumnModel().getColumn(0).setMaxWidth(60);
		tabla.getColumnModel().getColumn(3).setMaxWidth(100);
		tabla.getColumnModel().getColumn(4).setMaxWidth(100);
		tabla.getColumnModel().getColumn(5).setMaxWidth(80);

		tabla.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
			@Override
			public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
				Component comp = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
				if (!sel) {
					String stockStr = (String) t.getModel().getValueAt(r, 3);
					try {
						double stock = Double.parseDouble(stockStr);
						comp.setBackground(stock <= 0 ? new Color(255, 230, 230) : Estilos.BG_BLANCO);
					} catch (Exception e) {
						comp.setBackground(Estilos.BG_BLANCO);
					}
				}
				return comp;
			}
		});

		for (Producto p : bajos) {
			double faltante = Math.max(0, p.getStockMinimo() - p.getStock());
			modelo.addRow(new Object[] {
					p.getId(), p.getNombre(), p.getCategoria(),
					String.format("%.1f", p.getStock()),
					String.format("%.0f", p.getStockMinimo()),
					String.format("%.1f", faltante)
			});
		}
		if (bajos.isEmpty())
			modelo.addRow(new Object[] { "-", "Todos los productos tienen stock suficiente", "", "", "", "" });

		JScrollPane scroll = new JScrollPane(tabla);
		scroll.setBorder(BorderFactory.createLineBorder(Estilos.BORDE));
		scroll.getViewport().setBackground(Estilos.BG_BLANCO);
		scroll.setBounds(20, 72, 680, 350);
		dlg.add(scroll);

		JButton btnCerrar = Estilos.botonPrimario("Cerrar");
		btnCerrar.setBounds(300, 432, 120, 36);
		btnCerrar.addActionListener(e -> dlg.dispose());
		dlg.add(btnCerrar);

		ManejoErrores.registrarInfo("Reporte bajo stock: " + bajos.size() + " productos");
		dlg.setVisible(true);
	}

	private void abrirFormulario(Producto producto) {
		ProductoDialog dlg = new ProductoDialog(SwingUtilities.getWindowAncestor(this), producto, ctrl);
		dlg.setVisible(true);
		refrescar();
	}

	public static class ImagenRenderer extends DefaultTableCellRenderer {
		private final java.util.Map<String, ImageIcon> cache = new java.util.HashMap<>();

		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
				int row, int column) {
			JLabel lbl = new JLabel();
			lbl.setHorizontalAlignment(SwingConstants.CENTER);

			if (value != null && !value.toString().isEmpty()) {
				String ruta = value.toString();
				if (cache.containsKey(ruta)) {
					ImageIcon icon = cache.get(ruta);
					if (icon != null) {
						lbl.setIcon(icon);
						lbl.setText("");
					} else {
						lbl.setText("Sin foto");
					}
				} else {
					File archivo = new File(ruta);
					if (!archivo.isAbsolute() || !archivo.exists()) {
						String base = Util.RutaBase.getRaiz();
						archivo = new File(base, ruta);
					}
					if (archivo.exists()) {
						try {
							java.awt.image.BufferedImage bimg = javax.imageio.ImageIO.read(archivo);
							if (bimg != null) {
								Image img = bimg.getScaledInstance(45, 45, Image.SCALE_SMOOTH);
								ImageIcon finalIcon = new ImageIcon(img);
								cache.put(ruta, finalIcon);
								lbl.setIcon(finalIcon);
								lbl.setText("");
							} else {
								cache.put(ruta, null);
								lbl.setText("Sin foto");
							}
						} catch (Exception e) {
							cache.put(ruta, null);
							lbl.setText("Sin foto");
						}
					} else {
						cache.put(ruta, null);
						lbl.setText("Sin foto");
					}
				}
			} else {
				lbl.setText("Sin foto");
			}

			if (isSelected) {
				lbl.setBackground(table.getSelectionBackground());
				lbl.setOpaque(true);
			}
			return lbl;
		}
	}
}

		
			
			
		
	


